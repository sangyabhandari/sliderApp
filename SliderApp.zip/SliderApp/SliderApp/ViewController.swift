//
//  ViewController.swift
//  SliderApp
//
//  Created by akulanagamurali@gmail.com on 15/09/21.
//  Copyright © 2021 JAIN. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var slider1: UISlider!
    
    @IBOutlet var label1: UILabel!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func sliderMove() {
    
        let value1: Float = slider1.value
        
        print("\(value1)")
        
        label1.text = "Slider value is: \(value1)"
        
        self.view.alpha = CGFloat(slider1.value)
    
    }


}

